A Pen created at CodePen.io. You can find this one at https://codepen.io/dubrod/pen/osDmg.

 Custom UI for https://github.com/skidding/dragdealer with some preset data 